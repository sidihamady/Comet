-- Lua

cls()

io.write("Hello world!\n")
