-- io.read

cls()

io.write("\nEnter your name: ")
name = io.read("*a")
io.write("\nName: ", name)
