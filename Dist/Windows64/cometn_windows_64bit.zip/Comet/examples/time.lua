-- Timer

cls()

tic()
sleep(200)
dt = toc()
cls()
print(time.format(dt))
